"""
Package services pour EduPaie.
"""

from .eleve_service import EleveService
from .solde_service import SoldeService
from .paiement_service import PaiementService
from .recu_service import RecuService
from .fiche_eleve_service import FicheEleveService
from .dashboard_service import DashboardService
from .exceptions import ValidationError

# Import optionnel de recu_pdf (peut échouer sur certains systèmes)
try:
    from .recu_pdf import generer_recu_pdf, get_chemin_dossier_recus
    __all__ = ['EleveService', 'ValidationError', 'SoldeService', 'PaiementService', 'RecuService', 'generer_recu_pdf', 'get_chemin_dossier_recus', 'FicheEleveService', 'DashboardService']
except ImportError:
    __all__ = ['EleveService', 'ValidationError', 'SoldeService', 'PaiementService', 'RecuService', 'FicheEleveService', 'DashboardService']
