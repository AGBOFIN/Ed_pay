"""
Package tests pour EduPaie.
"""
